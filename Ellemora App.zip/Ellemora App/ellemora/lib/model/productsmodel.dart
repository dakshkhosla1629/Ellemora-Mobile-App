class ApiData {
  final id;
  final title;
  final price;
  final description;
  final category;
  final rating;
  final ratingCount;
  String image;

  ApiData({
    required this.id,
    required this.title,
    required this.price,
    required this.description,
    required this.category,
    required this.image,
    required this.rating,
    required this.ratingCount,
  });
}
