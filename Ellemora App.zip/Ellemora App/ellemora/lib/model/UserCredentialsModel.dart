class Usercredentialsmodel {
  String? email;
  String? name;

  Usercredentialsmodel(this.email, this.name);
}
