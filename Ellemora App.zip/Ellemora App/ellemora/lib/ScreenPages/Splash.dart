import 'dart:async';

import 'package:ellemora/utills/routesname.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:flutter/material.dart';

import 'package:shared_preferences/shared_preferences.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  Timer? splashtimer;
  @override
  void initState() {
    checkScreen();
    super.initState();
  }

  @override
  void dispose() {
    splashtimer?.cancel();
    super.dispose();
  }

  void checkScreen() {
    splashtimer = Timer(const Duration(seconds: 2), () async {
      final SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();

      var obtainedemail = sharedPreferences.getString('email');

      if (obtainedemail != null) {
        Navigator.pushReplacementNamed(context, RoutesName.homePage);
      } else {
        Navigator.pushReplacementNamed(context, RoutesName.loginpage);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SizedBox(
              height: 120,
              width: 240,
              child: Image(image: Utill.appLogo),
            ),
            const SizedBox(
              height: 10,
            ),
          ],
        ),
      ),
    );
  }
}
