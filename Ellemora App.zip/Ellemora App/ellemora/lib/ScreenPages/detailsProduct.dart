import 'package:ellemora/Providers/ApiProductsProvider.dart';
import 'package:ellemora/Providers/MyCartsprovider.dart';
import 'package:ellemora/model/productsmodel.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_expandable_text/flutter_expandable_text.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:rate_in_stars/rate_in_stars.dart';

class Detailsproduct extends StatefulWidget {
  final ApiData elementvalue;

  const Detailsproduct({super.key, required this.elementvalue});

  @override
  State<Detailsproduct> createState() => _DetailsproductState();
}

class _DetailsproductState extends State<Detailsproduct> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    print("build");
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: Utill.appbar2("Detail Product"),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Consumer<ApiProductsProvider>(
              builder: (context, value, child) {
                return Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ClipRRect(
                        child: Image.network(
                            height: MediaQuery.of(context).size.height / 3,
                            width: double.infinity,
                            fit: BoxFit.contain,
                            widget.elementvalue.image),
                      ),
                      const SizedBox(
                        height: 50,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Expanded(
                            child: Text(
                              widget.elementvalue.title,
                              overflow: TextOverflow.ellipsis,
                              maxLines: 7,
                              style: GoogleFonts.poppins(
                                  fontWeight: FontWeight.w500, fontSize: 14),
                            ),
                          ),
                          SizedBox(
                            width: MediaQuery.of(context).size.width / 7,
                          ),
                          Consumer<MycartsProvider>(
                            builder: (context, value, child) {
                              bool isFavorite =
                                  value.isInCart(widget.elementvalue);

                              return IconButton(
                                onPressed: () async {
                                  if (isFavorite) {
                                    value.removeFromCart(widget.elementvalue);
                                    await value.removeCartFromFirebase(
                                        widget.elementvalue);
                                  } else {
                                    value.addToCart(widget.elementvalue);
                                    value.addCartsToFirebase();
                                  }
                                  if (!isFavorite &&
                                      value.selecteditemCarts.isNotEmpty) {
                                    Utill.flushBarSuccessMessage(
                                      "${value.selecteditemCarts.first.title.toString()} Added to Cart",
                                      context,
                                    );

                                    print(value.selecteditemCarts.first.title);
                                  } else {
                                    print("Cart is empty");
                                  }
                                },
                                icon: Icon(
                                  isFavorite
                                      ? Icons.favorite
                                      : Icons.favorite_border,
                                  color: isFavorite
                                      ? Utill.textcolor
                                      : Utill.mainappcolor,
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      Row(
                        children: [
                          Text(
                            '₹ ${widget.elementvalue.price.toString()}',
                            style: GoogleFonts.poppins(
                              textStyle: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          RatingStars(
                            editable: false,
                            rating: widget.elementvalue.rating.toDouble(),
                            color: Utill.textcolor,
                            iconSize: 20,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Description Product",
                        style: GoogleFonts.poppins(
                          textStyle: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      ExpandableText(
                        widget.elementvalue.description.toString(),
                        readLessText: 'Read less',
                        readMoreText: 'Read More',
                        linkTextStyle: TextStyle(color: Utill.textcolor),
                        style: GoogleFonts.lato(
                          textStyle: const TextStyle(
                            fontSize: 14,
                            color: Color.fromARGB(255, 106, 105, 105),
                          ),
                        ),
                        textAlign: TextAlign.justify,
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Color.fromARGB(84, 245, 245, 245),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Consumer<MycartsProvider>(
              builder: (context, value, child) {
                bool isFavorite = value.isInCart(widget.elementvalue);
                return InkWell(
                  onTap: () async {
                    if (isFavorite) {
                      await value.removeCartFromFirebase(widget.elementvalue);
                      value.removeFromCart(widget.elementvalue);
                    } else {
                      value.addToCart(widget.elementvalue);
                      value.addCartsToFirebase();
                    }
                    if (!isFavorite && value.selecteditemCarts.isNotEmpty) {
                      Utill.flushBarSuccessMessage(
                        "${value.selecteditemCarts.first.title.toString()} Added to Cart",
                        context,
                      );

                      print(value.selecteditemCarts.first.title);
                    } else {
                      print("Cart is empty");
                    }
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15.0),
                      border: Border.all(
                        color: Utill.textcolor,
                      ),
                      color: Colors.transparent,
                    ),
                    width: MediaQuery.of(context).size.width / 3,
                    height: 100,
                    child: Row(
                      children: [
                        Consumer<MycartsProvider>(
                          builder: (context, value, child) {
                            bool isFavorite =
                                value.isInCart(widget.elementvalue);

                            return IconButton(
                              onPressed: () {},
                              icon: Icon(
                                Icons.shopping_bag_outlined,
                                color: isFavorite
                                    ? Utill.offshadecolor
                                    : Utill.mainappcolor,
                              ),
                            );
                          },
                        ),
                        Text(
                          "Add to Cart",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                                fontSize: 14, color: Utill.offshadecolor),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            InkWell(
              onTap: () {},
              child: Container(
                width: MediaQuery.of(context).size.width / 3,
                height: 100,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15.0),
                  color: Utill.offshadecolor,
                ),
                child: Row(
                  children: [
                    IconButton(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.shopping_cart_checkout,
                        color: Colors.white,
                      ),
                    ),
                    Text(
                      "Buy Now",
                      style: GoogleFonts.lato(
                        textStyle: TextStyle(fontSize: 14, color: Colors.white),
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
