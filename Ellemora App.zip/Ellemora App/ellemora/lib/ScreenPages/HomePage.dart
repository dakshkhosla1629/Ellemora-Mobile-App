import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:ellemora/NetworksApi/ApiResponse.dart';
import 'package:ellemora/Providers/ApiProductsProvider.dart';
import 'package:ellemora/utills/productsgrid.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

late Razorpay _razorpay;
late Future<void> _productsFuture;
late Future<void> _productsFuturecategory;

Apiresponse apiresponse = Apiresponse();

void _handlePaymentSuccess(PaymentSuccessResponse response) {}

void _handlePaymentError(PaymentFailureResponse response) {}

void _handleExternalWallet(ExternalWalletResponse response) {}

class _HomepageState extends State<Homepage> {
  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    _productsFuture = fetchProducts(context);
  }

  Future<void> fetchProducts(BuildContext context) async {
    var apiresponse = Apiresponse();
    await apiresponse.fetchAllProducts();
    Provider.of<ApiProductsProvider>(context, listen: false)
        .updateProducts(apiresponse.allproductsdata);
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  Widget buildImageContainer(String imageUrl, String placeholderImagePath) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Image.network(
          imageUrl,
          height: 170,
          width: double.infinity,
          fit: BoxFit.cover,
          errorBuilder:
              (BuildContext context, Object exception, StackTrace? stackTrace) {
            return Image.asset(
              placeholderImagePath,
              height: 170,
              width: double.infinity,
              fit: BoxFit.cover,
            );
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 5,
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: Utill.myAppBar("Ellemora", context),
          body: SafeArea(
              child: FutureBuilder(
            future: _productsFuture,
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              } else if (snapshot.hasError) {
                return Center(child: Text('Error: ${snapshot.error}'));
              } else {
                return SingleChildScrollView(
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Utill().searchbarAndCart(context),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Popular Items",
                              style: GoogleFonts.poppins(
                                textStyle: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                            ),
                            TextButton(
                              onPressed: () {},
                              child: Text(
                                "See All",
                                style: GoogleFonts.aBeeZee(
                                  textStyle: TextStyle(
                                      fontSize: 19,
                                      fontWeight: FontWeight.w300,
                                      color: Utill.textcolor),
                                ),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: const [
                              BoxShadow(
                                color: Color.fromRGBO(71, 71, 77, 0.409),
                                blurRadius: 20.0,
                                offset: Offset(0, 10),
                              )
                            ],
                          ),
                          child: CarouselSlider(
                            items: [
                              buildImageContainer(
                                "https://www.ellemora.com/wp-content/uploads/2023/09/about-section-2.png",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://i.ytimg.com/vi/lzRgMYrYNU0/maxresdefault.jpg",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://www.azafashions.com/blog/wp-content/uploads/2020/04/Untitled-design-19.png",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTSvxhcSbT5Zxye-LEsb1D-tJ4GirUvMKsZmXHBNLHrvFaJarOY--SuVsMx7Ne-ee3D-84&usqp=CAU",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2QFZV9stp0srsMuYkXK9EjEKCoje60ZUr9g&s",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://d1csarkz8obe9u.cloudfront.net/posterpreviews/fashion-jeans-sale-poster-template-6dd64377870b5712a26fbbeaa2eb7276_screen.jpg",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://c8.alamy.com/comp/H972PF/jeans-on-display-to-promote-sales-H972PF.jpg",
                                "assets/notfound.png",
                              ),
                              buildImageContainer(
                                "https://i.pinimg.com/474x/0b/4b/85/0b4b8526f5f722c8e5bbdd09e4b5287c--newsletter-design-email-design.jpg",
                                "assets/notfound.png",
                              ),
                            ],
                            options: CarouselOptions(
                              viewportFraction: 1,
                              autoPlay: true,
                              aspectRatio: 2.0,
                              enlargeCenterPage: false,
                              autoPlayCurve: Curves.fastOutSlowIn,
                              enableInfiniteScroll: false,
                              autoPlayAnimationDuration:
                                  const Duration(milliseconds: 800),
                            ),
                          ),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: ButtonsTabBar(
                            width:
                                (MediaQuery.of(context).size.width - 10) / 2.7,
                            backgroundColor: Utill.mainappcolor,
                            borderColor: Utill.mainappcolor,
                            contentPadding: EdgeInsets.all(1),
                            splashColor: Utill.MainOffshadeBackground,
                            unselectedBackgroundColor:
                                Utill.MainOffshadeBackground,
                            labelStyle: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.normal,
                            ),
                            labelSpacing: 2,
                            unselectedLabelStyle: const TextStyle(
                              color: Colors.black,
                              fontWeight: FontWeight.w300,
                            ),
                            borderWidth: 0,
                            contentCenter: true,
                            buttonMargin: const EdgeInsets.all(8),
                            unselectedBorderColor:
                                const Color.fromARGB(255, 84, 83, 83),
                            radius: 10,
                            tabs: const [
                              Tab(
                                text: "All Products",
                              ),
                              Tab(
                                text: "Jewelery",
                              ),
                              Tab(
                                text: "Electronics",
                              ),
                              Tab(
                                text: "Men's Clothings",
                              ),
                              Tab(
                                text: "Women's Clothings",
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(
                          height: 10,
                        ),
                        SizedBox(
                          height: 500,
                          child: TabBarView(
                            children: [
                              FutureBuilder(
                                future: fetchProducts(
                                  context,
                                ),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return const Center(
                                        child: CircularProgressIndicator());
                                  } else if (snapshot.hasError) {
                                    return Center(
                                        child:
                                            Text('Error: ${snapshot.error}'));
                                  } else {
                                    return Center(
                                      child: Productsgrid.mygridviewproduct(
                                          context, Utill().searchitem),
                                    );
                                  }
                                },
                              ),
                              FutureBuilder(
                                future: fetchProducts(
                                  context,
                                ),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return const Center(
                                        child: CircularProgressIndicator());
                                  } else if (snapshot.hasError) {
                                    return Center(
                                        child:
                                            Text('Error: ${snapshot.error}'));
                                  } else {
                                    return Center(
                                      child: Productsgrid
                                          .mygridviewproductcategory(
                                              context, "Jewelery"),
                                    );
                                  }
                                },
                              ),
                              FutureBuilder(
                                future: fetchProducts(
                                  context,
                                ),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return const Center(
                                        child: CircularProgressIndicator());
                                  } else if (snapshot.hasError) {
                                    return Center(
                                      child: Text('Error: ${snapshot.error}'),
                                    );
                                  } else {
                                    return Center(
                                      child: Productsgrid
                                          .mygridviewproductcategory(
                                              context, "Electronics"),
                                    );
                                  }
                                },
                              ),
                              FutureBuilder(
                                future: fetchProducts(
                                  context,
                                ),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return const Center(
                                        child: CircularProgressIndicator());
                                  } else if (snapshot.hasError) {
                                    return Center(
                                        child:
                                            Text('Error: ${snapshot.error}'));
                                  } else {
                                    return Center(
                                      child: Productsgrid
                                          .mygridviewproductcategory(
                                              context, "Men's Clothings"),
                                    );
                                  }
                                },
                              ),
                              FutureBuilder(
                                future: fetchProducts(
                                  context,
                                ),
                                builder: (context, snapshot) {
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting) {
                                    return const Center(
                                        child: CircularProgressIndicator());
                                  } else if (snapshot.hasError) {
                                    return Center(
                                        child:
                                            Text('Error: ${snapshot.error}'));
                                  } else {
                                    return Center(
                                      child: Productsgrid
                                          .mygridviewproductcategory(
                                              context, "Women's Clothings"),
                                    );
                                  }
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }
            },
          )),
        ));
  }
}
