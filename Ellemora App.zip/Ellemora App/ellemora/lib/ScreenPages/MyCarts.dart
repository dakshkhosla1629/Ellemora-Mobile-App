import 'package:ellemora/Providers/MyCartsprovider.dart';
import 'package:ellemora/utills/productsgrid.dart';

import 'package:ellemora/utills/utills.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';

class MyCarts extends StatefulWidget {
  const MyCarts({super.key});

  @override
  State<MyCarts> createState() => _MyCartsState();
}

class _MyCartsState extends State<MyCarts> {
  late Razorpay _razorpay;
  var totalPrice = 0.0;
  String productname = "";

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    Provider.of<MycartsProvider>(context, listen: false).fetchcartsData();
  }

  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  void openbuynowportal() async {
    var options = {
      'key': 'rzp_test_abHik7bpW2XS0D',
      'amount': (totalPrice * 100).toInt(),
      'name': 'Ellemora',
      'description': productname,
      'prefill': {'contact': '7009447986', 'email': 'daksh@razorpay.com'},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Razorpay Error: ${e.toString()}');
    }
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {}

  void _handlePaymentError(PaymentFailureResponse response) {}

  void _handleExternalWallet(ExternalWalletResponse response) {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: Utill.appbar2("My Cart"),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Productsgrid().mylistviewbuilder(context),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: const Color.fromARGB(84, 245, 245, 245),
        child: Consumer<MycartsProvider>(
          builder: (context, value, child) {
            if (value.selecteditemCarts.isEmpty) {
              return Container(
                height: 100,
                alignment: Alignment.center,
                child: Text(
                  "No items in cart",
                  style: GoogleFonts.poppins(
                    textStyle: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w500,
                      color: Utill.textcolor,
                    ),
                  ),
                ),
              );
            } else {
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width / 3,
                    height: 100,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Total",
                          style: GoogleFonts.lato(
                            textStyle: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: Utill.mainappcolor,
                            ),
                          ),
                        ),
                        Consumer<MycartsProvider>(
                          builder: (context, value, child) {
                            totalPrice = 0.0;
                            for (var item in value.selecteditemCarts) {
                              totalPrice += item.price ?? 0.0;
                              productname = item.title;
                            }
                            return Text(
                              "₹ ${totalPrice.toInt()}",
                              style: GoogleFonts.aBeeZee(
                                textStyle: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  InkWell(
                    onTap: () {
                      openbuynowportal();
                    },
                    child: Container(
                      width: MediaQuery.of(context).size.width / 3,
                      height: 100,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.0),
                        color: Utill.offshadecolor,
                      ),
                      child: Row(
                        children: [
                          IconButton(
                            onPressed: () {},
                            icon: const Icon(
                              Icons.shopping_cart_checkout,
                              color: Colors.white,
                            ),
                          ),
                          Text(
                            "Buy Now",
                            style: GoogleFonts.lato(
                              textStyle: const TextStyle(
                                fontSize: 14,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              );
            }
          },
        ),
      ),
    );
  }
}
