import 'dart:convert';

import 'package:ellemora/model/productsmodel.dart';
import 'package:http/http.dart' as http;

class Apiresponse {
  List<ApiData> allproductsdata = [];

  Future<void> fetchAllProducts() async {
    var url1 = "https://fakestoreapi.com/products";

    print(url1);

    final response1 = await http.get(Uri.parse(url1));

    if (response1.statusCode == 200) {
      List<dynamic> data = json.decode(response1.body);
      print(data.length);
      allproductsdata.clear();

      for (var product in data) {
        var id = product['id'];
        String title = product['title'];
        var price = product['price'];
        String description = product['description'];
        String category = product['category'];
        String image = product['image'];
        var rating = product['rating']['rate'];
        var ratingCount = product['rating']['count'];

        allproductsdata.add(ApiData(
          id: id,
          title: title,
          price: price,
          description: description,
          category: category,
          image: image,
          rating: rating,
          ratingCount: ratingCount,
        ));
        print(allproductsdata[0].description);
      }
    }
  }

}
