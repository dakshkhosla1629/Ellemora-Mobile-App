import 'dart:core';
import 'package:flutter/material.dart';
import '../model/productsmodel.dart';

class ApiProductsProvider with ChangeNotifier {
  List<ApiData> _allproductsdata = [];
  List<ApiData> _jewldata = [];
  List<ApiData> _eledata = [];
  List<ApiData> _mendata = [];
  List<ApiData> _womendata = [];
  List<ApiData> _searchResults = [];

  List<ApiData> get listofallproduct => _allproductsdata;
  List<ApiData> get listofjewldata => _jewldata;
  List<ApiData> get listofeledata => _eledata;
  List<ApiData> get listofmendata => _mendata;
  List<ApiData> get listofwomendata => _womendata;
  List<ApiData> get searchResults => _searchResults;

  void updateProducts(List<ApiData> products) {
    _allproductsdata = products;
    _categorizeProducts();
    notifyListeners();
  }

  void _categorizeProducts() {
    _jewldata.clear();
    _eledata.clear();
    _mendata.clear();
    _womendata.clear();

    for (var product in _allproductsdata) {
      switch (product.category) {
        case 'jewelery':
          _jewldata.add(product);
          break;
        case 'electronics':
          _eledata.add(product);
          break;
        case 'men\'s clothing':
          _mendata.add(product);
          break;
        case 'women\'s clothing':
          _womendata.add(product);
          break;
      }
    }
    print("Jewellery Products: $_jewldata");
    print("Electronics Products: $_eledata");
    print("Men's Clothing Products: $_mendata");
    print("Women's Clothing Products: $_womendata");
  }

 void searchProducts(String query) {
    if (query.isEmpty) {
      _searchResults = _allproductsdata;
    } else {
      _searchResults = _allproductsdata
          .where((product) =>
              product.title.toLowerCase().contains(query.toLowerCase()))
          .toList();
          print(_searchResults);
    }
    notifyListeners();
  }
}
