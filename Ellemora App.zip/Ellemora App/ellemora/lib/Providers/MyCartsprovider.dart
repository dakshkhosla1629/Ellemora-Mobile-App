import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ellemora/model/productsmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class MycartsProvider with ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final List<ApiData> _cartsList = [];
  final List<String> _cartDocumentIds = [];
  final Set<String> _addedItemIds = {};

  List<ApiData> get selecteditemCarts => _cartsList;

  MycartsProvider() {
    fetchcartsData();
  }

  String? getCurrentUserId() {
    return _auth.currentUser?.uid;
  }

  void addToCart(ApiData item) {
    if (!_cartsList.contains(item)) {
      _cartsList.add(item);
      notifyListeners();
    }
  }

  void removeFromCart(ApiData item) {
    if (_cartsList.contains(item)) {
      _cartsList.remove(item);
      _addedItemIds.remove(item.id.toString());
      notifyListeners();
    }
  }

  bool isInCart(ApiData item) {
    return _cartsList.contains(item);
  }

  Future<void> addCartsToFirebase() async {
    try {
      String userId = getCurrentUserId()!;
      Set<ApiData> uniqueCarts = _cartsList.toSet();
      for (var data in uniqueCarts) {
        if (!_addedItemIds.contains(data.id.toString())) {
          DocumentReference docRef = await _firestore
              .collection("users")
              .doc(userId)
              .collection("CartsItem")
              .add({
            "title": data.title,
            "price": data.price,
            "image": data.image,
            "id": data.id.toString(),
          });
          _cartDocumentIds.add(docRef.id);
          _addedItemIds.add(data.id.toString());
          print("Added item to Firestore with ID: ${docRef.id}");
        }
      }
      print("Data added to Firebase");
    } catch (e) {
      print("Firestore error: $e");
      throw Exception("Failed to add data to Firestore");
    }
  }

  Future<void> removeCartFromFirebase(ApiData item) async {
    try {
      String userId = getCurrentUserId()!;
      QuerySnapshot querySnapshot = await _firestore
          .collection("users")
          .doc(userId)
          .collection("CartsItem")
          .where("id", isEqualTo: item.id.toString())
          .get();

      for (var doc in querySnapshot.docs) {
        await _firestore
            .collection("users")
            .doc(userId)
            .collection("CartsItem")
            .doc(doc.id)
            .delete();
        _cartDocumentIds.remove(doc.id);
        _addedItemIds.remove(item.id.toString());
        print("Document ${doc.id} deleted from Firebase");
      }

      print("Item deleted from Firebase");
    } catch (e) {
      print("Firestore error: $e");
      throw Exception("Failed to delete item from Firestore");
    }
  }

  Future<void> fetchcartsData() async {
    try {
      String userId = getCurrentUserId()!;
      final response = await _firestore
          .collection("users")
          .doc(userId)
          .collection("CartsItem")
          .get();

      if (response.docs.isNotEmpty) {
        _cartsList.clear();
        for (var data in response.docs) {
          double price = data["price"].toDouble();
          String title = data['title'];
          String image = data['image'];
          String id = data['id'];

          _cartsList.add(ApiData(
            id: id,
            title: title,
            price: price.toDouble(),
            description: "description",
            category: "category",
            image: image,
            rating: "rating",
            ratingCount: "ratingCount",
          ));
          _addedItemIds.add(id);
          _cartDocumentIds.add(data.id);
        }
        notifyListeners();
      }
      print("Fetched cart data from Firebase for user $userId");
    } catch (e) {
      print("Firestore error: $e");
      throw Exception("Failed to fetch data from Firestore");
    }
  }
}
