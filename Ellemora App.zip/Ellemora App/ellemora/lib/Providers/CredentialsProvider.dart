import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ellemora/model/UserCredentialsModel.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_network_connectivity/flutter_network_connectivity.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Credentialsprovider with ChangeNotifier {
  static bool _isObscure = true;
  bool get isobscure => _isObscure;

  static bool _isloading = false;
  bool get isloading => _isloading;

  List<Usercredentialsmodel> userdata = [];
  void passwordVisible() {
    _isObscure = !_isObscure;
    notifyListeners();
  }

  Future<void> logout(BuildContext context) async {
    final SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
    final FirebaseAuth auth = FirebaseAuth.instance;
    await sharedPreferences.clear();
    await auth.signOut();
    Navigator.pushReplacementNamed(context, RoutesName.loginpage);
  }

  Future<void> login(
    BuildContext context,
    String useremail,
    String userpassword,
  ) async {
    setLoading(true);
    try {
      await Future.delayed(const Duration(seconds: 1));
      checkInternetConnection(context);

      UserCredential userCredentials = await FirebaseAuth.instance
          .signInWithEmailAndPassword(email: useremail, password: userpassword);

      final response = await FirebaseFirestore.instance
          .collection("Credentials")
          .where("useremail", isEqualTo: useremail)
          .get();

      if (response.docs.isNotEmpty) {
        var data = response.docs.first;
        print(data);
        String email = data['useremail'];
        String name = data['username'];
        userdata.add(Usercredentialsmodel(name, email));
        Navigator.of(context).pushNamedAndRemoveUntil(
            RoutesName.homePage, (Route<dynamic> route) => false);
        Credentialsprovider().saveUserEmail(email);
      } else {
        Utill.flushBarNewErrorMessage("No Account Found", context);
      }
    } catch (e) {
      Utill.flushBarNewErrorMessage("User Details Are Incorrect", context);
      print("Exception: $e");
    } finally {
      setLoading(false);
    }
  }

  Future<void> checkInternetConnection(BuildContext context) async {
    FlutterNetworkConnectivity flutterNetworkConnectivity =
        FlutterNetworkConnectivity(
      isContinousLookUp: true,
    );

    bool isNetworkConnectedOnCall =
        await flutterNetworkConnectivity.isInternetConnectionAvailable();

    print("Connectivity result: $isNetworkConnectedOnCall");

    if (!isNetworkConnectedOnCall) {
      print("No internet connection");
      Utill.flushBarErrorMessage(
          "Please check your internet connection and try again", context);
    } else {
      Utill.flushBarErrorMessage("Internet is Connected", context);
    }
  }

  Future<void> changesignupstate(BuildContext context, String useremail,
      String userpassword, String username) async {
    setLoading(true);
    try {
      final employeecred = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: useremail, password: userpassword);

      if (employeecred.user!.uid.isNotEmpty) {
        await _addUserToFirestore(username, useremail);
        await saveUserEmail(useremail);
        Navigator.pushReplacementNamed(context, RoutesName.homePage);
      }
    } catch (error) {
      print("Error: $error");
      Utill.flushBarErrorMessage(error.toString(), context);
    } finally {
      setLoading(false);
    }
  }

  Future<void> _addUserToFirestore(String username, String useremail) async {
    try {
      await FirebaseFirestore.instance.collection("Credentials").add({
        "username": username,
        "useremail": useremail,
      });
    } catch (e) {
      print("Firestore error: $e");
      throw Exception("Failed to add user to Firestore");
    }
  }

  Future<void> saveUserEmail(String email) async {
    try {
      final SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      await sharedPreferences.setString('email', email);
    } catch (e) {
      print("SharedPreferences error: $e");
      throw Exception("Failed to save user email");
    }
  }

  void setLoading(bool value) {
    _isloading = value;
    notifyListeners();
  }
}
