import 'package:another_flushbar/flushbar.dart';
import 'package:another_flushbar/flushbar_route.dart';
import 'package:ellemora/Providers/ApiProductsProvider.dart';
import 'package:ellemora/Providers/CredentialsProvider.dart';
import 'package:ellemora/Providers/MyCartsprovider.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:badges/badges.dart' as badges;

class Utill {
  String searchitem = '';
  TextEditingController searchController = TextEditingController();

  void handleSearch(String query, BuildContext context) {
    searchController.text = query;
    Provider.of<ApiProductsProvider>(context, listen: false)
        .searchProducts(query);
  }

  static NetworkImage appLogo = const NetworkImage(
      "https://www.ellemora.com/wp-content/uploads/2023/09/ellemora-logo-1.png");

  static Color textcolor = const Color.fromARGB(255, 184, 155, 104);
  static Color mainappcolor = const Color.fromARGB(255, 81, 81, 81);
  static Color offshadecolor = const Color.fromARGB(255, 184, 155, 104);
  static Color MainOffshadeBackground =
      const Color.fromARGB(123, 249, 243, 231);

  static void flushBarErrorMessage(String message, BuildContext context) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          message: message,
          flushbarPosition: FlushbarPosition.TOP,
          borderRadius: BorderRadius.circular(10),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.all(12),
          duration: const Duration(seconds: 3),
          forwardAnimationCurve: Curves.decelerate,
        )..show(context));
  }

  static void flushBarNewErrorMessage(String message, BuildContext context) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          icon: const Icon(Icons.warning_amber),
          backgroundColor: Colors.black38,
          message: message,
          flushbarPosition: FlushbarPosition.BOTTOM,
          borderRadius: BorderRadius.circular(10),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.all(12),
          duration: const Duration(seconds: 3),
          forwardAnimationCurve: Curves.decelerate,
        )..show(context));
  }

  static void flushBarSuccessMessage(String message, BuildContext context) {
    showFlushbar(
        context: context,
        flushbar: Flushbar(
          icon: Icon(
            Icons.shopping_cart,
            color: Utill.offshadecolor,
          ),
          backgroundColor: Utill.mainappcolor,
          message: message,
          flushbarPosition: FlushbarPosition.BOTTOM,
          borderRadius: BorderRadius.circular(10),
          margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          padding: const EdgeInsets.all(12),
          duration: const Duration(seconds: 3),
          forwardAnimationCurve: Curves.decelerate,
        )..show(context));
  }

  static PreferredSizeWidget myAppBar(String title, BuildContext context) {
    final provider = Provider.of<Credentialsprovider>(context);
    return AppBar(
      automaticallyImplyLeading: false,
      backgroundColor: Utill.MainOffshadeBackground,
      title: Text(
        "$title",
        style: GoogleFonts.poppins(fontSize: 25, color: Utill.textcolor),
      ),
      actions: [
        InkWell(
            onTap: () {
              provider.logout(context);
            },
            child: Icon(Icons.logout))
      ],
    );
  }

  static PreferredSizeWidget appbar2(String title) {
    return AppBar(
      backgroundColor: Colors.white,
      centerTitle: true,
      title: Text(
        "$title",
        style: GoogleFonts.poppins(fontSize: 19, color: Utill.textcolor),
      ),
    );
  }

  Widget searchbarAndCart(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Flexible(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: const Color.fromARGB(31, 154, 150, 150),
                borderRadius: BorderRadius.circular(30),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: searchController,
                      decoration: const InputDecoration(
                        hintText: 'Search',
                        border: InputBorder.none,
                      ),
                      onChanged: (value) {
                        print(searchitem);
                        searchitem = value;
                        Utill().handleSearch(searchitem, context);
                      },
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.search, color: Colors.grey),
                    onPressed: () {
                      searchitem = searchController.text;
                      handleSearch(searchitem, context);
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(width: 10),
        Consumer<MycartsProvider>(
          builder: (context, value, child) {
            return SizedBox(
              height: 50,
              width: 30,
              child: badges.Badge(
                badgeStyle: badges.BadgeStyle(
                  elevation: 1,
                  padding: const EdgeInsets.all(4),
                  shape: badges.BadgeShape.circle,
                  badgeColor: Utill.textcolor,
                ),
                badgeContent: Text(value.selecteditemCarts.length.toString()),
                child: IconButton(
                  icon: const Icon(Icons.add_shopping_cart, color: Colors.grey),
                  onPressed: () {
                    Navigator.pushNamed(context, RoutesName.myCarts);
                  },
                ),
              ),
            );
          },
        ),
      ],
    );
  }
}
