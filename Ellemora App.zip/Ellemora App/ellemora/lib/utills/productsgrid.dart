import 'package:ellemora/Providers/ApiProductsProvider.dart';
import 'package:ellemora/Providers/MyCartsprovider.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:rate_in_stars/rate_in_stars.dart';

import '../model/productsmodel.dart';

class Productsgrid {
  String? userId = FirebaseAuth.instance.currentUser?.uid;

  static Widget mygridviewproduct(BuildContext context, String searchQuery) {
    return Consumer<ApiProductsProvider>(builder: (context, value, child) {
      List<ApiData> filteredProducts = value.searchResults;
      List<ApiData> productsToShow = filteredProducts.isNotEmpty
          ? filteredProducts
          : value.listofallproduct;
      return GridView.builder(
          shrinkWrap: true,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              mainAxisExtent: 310,
              crossAxisCount: 2,
              crossAxisSpacing: 25.0,
              mainAxisSpacing: 12.0),
          itemCount: productsToShow.length,
          itemBuilder: (_, index) {
            final product = productsToShow[index];

            return GestureDetector(
              onTap: () {
                print("Tapped on product: ${product.title}");

                Navigator.pushNamed(
                  context,
                  RoutesName.detailsproduct,
                  arguments: product,
                );
              },
              child: Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.all(25.0),
                    child: ClipRRect(
                      borderRadius: const BorderRadius.only(
                        topLeft: Radius.circular(10),
                        topRight: Radius.circular(10),
                      ),
                      child: Image.network(
                        height: 170,
                        width: double.infinity,
                        fit: BoxFit.fill,
                        product.image.toString(),
                      ),
                    ),
                  ),
                  Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        color: Colors.grey[49]),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                product.title.toString(),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              const SizedBox(
                                height: 8.0,
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  RatingStars(
                                    editable: false,
                                    rating: product.rating.toDouble(),
                                    color: Utill.textcolor,
                                    iconSize: 20,
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 8.0,
                              ),
                              Text(
                                '₹ ${product.price.toString()}',
                                style: GoogleFonts.poppins(
                                  textStyle: const TextStyle(
                                    fontSize: 15,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  ),
                ],
              ),
            );
          });
    });
  }

  Widget mylistviewbuilder(BuildContext context) {
    return SizedBox(
      height: MediaQuery.of(context).size.height,
      child: Consumer<MycartsProvider>(
        builder: (context, value, child) {
          return ListView.builder(
            scrollDirection: Axis.vertical,
            padding: const EdgeInsets.all(20),
            itemCount: value.selecteditemCarts.length,
            itemBuilder: (context, index) {
              return Container(
                margin: const EdgeInsets.all(6.0),
                width: MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16.0),
                    color: const Color.fromARGB(69, 244, 240, 240),
                    border: Border.all(color: Colors.grey)),
                child: Padding(
                  padding: const EdgeInsets.all(7.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      ClipRRect(
                        child: Image.network(
                          value.selecteditemCarts
                              .elementAt(index)
                              .image
                              .toString(),
                          height: 110,
                          fit: BoxFit.contain,
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: MediaQuery.of(context).size.height / 7,
                              color: Colors.white,
                              child: Padding(
                                padding: const EdgeInsets.only(bottom: 2.0),
                                child: Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Flexible(
                                      child: Text(
                                        value.selecteditemCarts
                                            .elementAt(index)
                                            .title,
                                        overflow: TextOverflow.fade,
                                        maxLines: 9,
                                        style: GoogleFonts.poppins(
                                            color: Color.fromARGB(
                                                255, 118, 117, 117),
                                            fontWeight: FontWeight.w600,
                                            fontSize: 12),
                                      ),
                                    ),
                                    Flexible(
                                      child: Text(
                                        '₹ ${value.selecteditemCarts.elementAt(index).price.toString()}',
                                        style: GoogleFonts.aBeeZee(
                                          textStyle: const TextStyle(
                                            fontSize: 17,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Consumer<MycartsProvider>(
                                      builder: (context, value, child) {
                                        bool isFavorite = value.isInCart(value
                                            .selecteditemCarts
                                            .elementAt(index));

                                        return IconButton(
                                          onPressed: () async {
                                            if (isFavorite) {
                                              await value
                                                  .removeCartFromFirebase(value
                                                      .selecteditemCarts
                                                      .elementAt(index));
                                              value.removeFromCart(value
                                                  .selecteditemCarts
                                                  .elementAt(index));
                                            } else {
                                              value.addToCart(value
                                                  .selecteditemCarts
                                                  .elementAt(index));
                                            }
                                            if (value
                                                .selecteditemCarts.isNotEmpty) {
                                              Utill.flushBarSuccessMessage(
                                                "${value.selecteditemCarts.elementAt(index).title} Removed from Cart",
                                                context,
                                              );
                                              print(value.selecteditemCarts
                                                  .first.title);
                                            } else {
                                              print("Cart is empty");
                                            }
                                          },
                                          icon: Icon(
                                            isFavorite
                                                ? Icons.favorite
                                                : Icons.favorite_border,
                                            color: isFavorite
                                                ? Utill.textcolor
                                                : Utill.mainappcolor,
                                          ),
                                        );
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  static Widget mygridviewproductcategory(
      BuildContext context, String category) {
    return Consumer<ApiProductsProvider>(builder: (context, value, child) {
      List<ApiData> productList;

      switch (category) {
        case 'Jewelery':
          productList = value.listofjewldata;
          break;
        case 'Electronics':
          productList = value.listofeledata;
          break;
        case "Men's Clothings":
          productList = value.listofmendata;
          break;
        case "Women's Clothings":
          productList = value.listofwomendata;
          break;
        default:
          productList = value.listofallproduct;
      }

      return GridView.builder(
        shrinkWrap: true,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          mainAxisExtent: 310,
          crossAxisCount: 2,
          crossAxisSpacing: 25.0,
          mainAxisSpacing: 12.0,
        ),
        itemCount: productList.length,
        itemBuilder: (_, index) {
          final product = productList.elementAt(index);

          return GestureDetector(
            onTap: () {
              print("Tapped on product: ${product.title}");

              Navigator.pushNamed(
                context,
                RoutesName.detailsproduct,
                arguments: product,
              );
            },
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(25.0),
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10),
                    ),
                    child: Image.network(
                      height: 170,
                      width: double.infinity,
                      fit: BoxFit.fill,
                      product.image.toString(),
                    ),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(5.0),
                    color: Colors.grey[49],
                  ),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              product.title.toString(),
                              overflow: TextOverflow.ellipsis,
                              maxLines: 1,
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                RatingStars(
                                  editable: false,
                                  rating: product.rating.toDouble(),
                                  color: Utill.textcolor,
                                  iconSize: 20,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            Text(
                              '₹ ${product.price.toString()}',
                              style: GoogleFonts.poppins(
                                textStyle: const TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      );
    });
  }
}
