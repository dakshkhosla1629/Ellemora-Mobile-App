class RoutesName {
  static const String splash = 'splashscreen';
  static const String loginpage = 'loginpage';
  static const String homePage = 'Homepage';
  static const String signup = 'Signuppage';
  static const String detailsproduct = 'Detailsproduct';
  static const String myCarts = 'MyCarts';
}
