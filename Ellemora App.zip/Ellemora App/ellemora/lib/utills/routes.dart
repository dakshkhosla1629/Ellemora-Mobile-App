import 'package:ellemora/Credentials/Loginpage.dart';
import 'package:ellemora/Credentials/Signup.dart';
import 'package:ellemora/ScreenPages/MyCarts.dart';
import 'package:ellemora/ScreenPages/Splash.dart';
import 'package:ellemora/ScreenPages/detailsProduct.dart';
import 'package:ellemora/ScreenPages/HomePage.dart';
import 'package:ellemora/model/productsmodel.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:flutter/material.dart';

class Routes {
  static Route<dynamic> generateroutes(RouteSettings settings) {
    switch (settings.name) {
      case RoutesName.splash:
        return MaterialPageRoute(
            builder: (BuildContext context) => const Splash());

      case RoutesName.loginpage:
        return MaterialPageRoute(
            builder: (BuildContext context) => const LoginPage());

      case RoutesName.signup:
        return MaterialPageRoute(
            builder: (BuildContext context) => const SignUpPage());

      case RoutesName.homePage:
        return MaterialPageRoute(
            builder: (BuildContext context) => const Homepage());

      case RoutesName.myCarts:
        return MaterialPageRoute(
            builder: (BuildContext context) => const MyCarts());

      case RoutesName.detailsproduct:
        final product = settings.arguments as ApiData;

        return MaterialPageRoute(
            builder: (BuildContext context) => Detailsproduct(
                  elementvalue: product,
                ));

      default:
        return MaterialPageRoute(builder: (_) {
          return const Scaffold(
            body: Center(
              child: Text("No Route Found"),
            ),
          );
        });
    }
  }
}
