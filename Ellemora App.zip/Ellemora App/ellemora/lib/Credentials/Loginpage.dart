import 'package:ellemora/Providers/CredentialsProvider.dart';
import 'package:ellemora/model/UserCredentialsModel.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:ellemora/utills/utills.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../Animations/FadeAnimation.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  bool isLoading = false;
  List<Usercredentialsmodel> userdata = [];
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    print("build");
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(
                height: 50,
              ),
              FadeAnimation(
                1.3,
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "     Login",
                      style: GoogleFonts.poppins(
                        textStyle: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w600,
                          color: Utill.textcolor,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(
                height: 50,
              ),
              FadeAnimation(
                1.3,
                SizedBox(
                  height: 120,
                  width: 240,
                  child: Image(image: Utill.appLogo),
                ),
              ),
              Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: Column(children: [
                    FadeAnimation(
                      1.5,
                      Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [
                            BoxShadow(
                              color: Color.fromRGBO(231, 203, 138, 0.269),
                              blurRadius: 20.0,
                              offset: Offset(0, 10),
                            )
                          ],
                        ),
                        child: Form(
                          key: _formKey,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Column(
                              children: [
                                TextFormField(
                                  controller: _emailController,
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    hintText: "Username",
                                    prefixIcon:
                                        const Icon(Icons.person_2_outlined),
                                    prefixIconColor: Utill.offshadecolor,
                                    hintStyle: TextStyle(
                                      color: Colors.grey[400],
                                    ),
                                  ),
                                  validator: (value) {
                                    if (value!.isEmpty) {
                                      return 'Please enter your Username';
                                    }

                                    return null;
                                  },
                                ),
                                Divider(
                                  color: Utill.textcolor,
                                  thickness: 2,
                                ),
                                Consumer<Credentialsprovider>(
                                  builder: (context, value, child) {
                                    print("Visible");
                                    return TextFormField(
                                      controller: _passwordController,
                                      obscureText: value.isobscure,
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          hintText: "Password",
                                          prefixIcon: const Icon(Icons.key),
                                          prefixIconColor: Utill.offshadecolor,
                                          suffixIcon: IconButton(
                                            icon: Icon(value.isobscure
                                                ? Icons.visibility_off
                                                : Icons.visibility),
                                            onPressed: () {
                                              value.passwordVisible();
                                            },
                                          ),
                                          hintStyle: TextStyle(
                                              color: Colors.grey[400])),
                                      validator: (value) {
                                        if (value!.isEmpty) {
                                          return 'Please enter your password';
                                        }
                                        return null;
                                      },
                                    );
                                  },
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ])),
              const SizedBox(
                height: 15,
              ),
              FadeAnimation(
                1.5,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          height: 45,
                          width: 200,
                          decoration: BoxDecoration(
                            color: Utill.textcolor,
                            shape: BoxShape.rectangle,
                            borderRadius: const BorderRadius.horizontal(
                              left: Radius.circular(120.0),
                            ),
                            boxShadow: [
                              BoxShadow(
                                  color: Utill.textcolor,
                                  blurRadius: 8,
                                  offset: const Offset(5, 0)),
                            ],
                          ),
                          child: Consumer<Credentialsprovider>(
                            builder: (context, value, child) {
                              return ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  elevation: 0,
                                  backgroundColor: Utill.textcolor,
                                ),
                                onPressed: () {
                                  if (_formKey.currentState!.validate()) {
                                    value.login(context, _emailController.text,
                                        _passwordController.text);
                                  }
                                },
                                child: value.isloading
                                    ? const CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                Colors.white),
                                      )
                                    : const Text(
                                        "Login",
                                        style: TextStyle(
                                          color: Colors.white,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                              );
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 70,
                    ),
                    Container(
                      height: 80,
                      width: 200,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 20),
                            child: TextButton.icon(
                              style: TextButton.styleFrom(
                                  foregroundColor: Utill.textcolor,
                                  textStyle: const TextStyle(fontSize: 20)),
                              icon: const Icon(Icons.arrow_forward),
                              onPressed: () {
                                Navigator.pushNamed(context, RoutesName.signup);
                              },
                              label: Text(
                                "Sign Up",
                                style: GoogleFonts.poppins(
                                  fontSize: 25,
                                  fontWeight: FontWeight.bold,
                                  color: const Color.fromRGBO(
                                    97,
                                    97,
                                    97,
                                    1.000,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
