import 'package:ellemora/utills/routesname.dart';
import 'package:ellemora/utills/utills.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import '../Animations/FadeAnimation.dart';
import '../Providers/CredentialsProvider.dart';

class SignUpPage extends StatefulWidget {
  const SignUpPage({super.key});

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final GlobalKey<FormState> SignUpKey = GlobalKey<FormState>();

  final TextEditingController FnameController = TextEditingController();
  final TextEditingController LnameController = TextEditingController();
  final TextEditingController PhoneNumberController = TextEditingController();
  final TextEditingController EmailController = TextEditingController();
  final TextEditingController PasswordController = TextEditingController();
  final TextEditingController ConfirmPasswordController =
      TextEditingController();

  String fname = "";
  String email = "";
  String password = "";
  String confirmpassword = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: FadeAnimation(
            1.3,
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 30, top: 70),
                  child: Text(
                    "Create an account",
                    style: GoogleFonts.aBeeZee(
                        fontSize: 30,
                        fontWeight: FontWeight.w500,
                        color: Utill.textcolor),
                  ),
                ),
                Column(
                  children: [
                    SizedBox(
                      height: 140,
                      width: 240,
                      child: Image(image: Utill.appLogo),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Center(
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            boxShadow: const [
                              BoxShadow(
                                color: Color.fromARGB(88, 205, 203, 203),
                                blurRadius: 20.0,
                                offset: Offset(0, 10),
                              )
                            ],
                          ),
                          child: Column(
                            children: [
                              Form(
                                key: SignUpKey,
                                child: Padding(
                                  padding: const EdgeInsets.all(18.0),
                                  child: Column(
                                    children: [
                                      TextFormField(
                                        controller: FnameController,
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                              color: Color.fromARGB(
                                                  139, 183, 183, 183),
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                              color: Colors.grey,
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          hintText: "Daksh khosla",
                                          label: Text("First Name",
                                              style: GoogleFonts.aBeeZee(
                                                  color: Colors.black45)),
                                          prefixIcon: const Icon(
                                              Icons.person_2_outlined),
                                          prefixIconColor: Utill.textcolor,
                                          hintStyle: TextStyle(
                                            color: Colors.grey[400],
                                          ),
                                        ),
                                        validator: (value) {
                                          if (value!.isNotEmpty) {
                                            fname = FnameController.text;
                                          } else {
                                            return 'Please enter Your First Name';
                                          }
                                          return null;
                                        },
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      TextFormField(
                                          controller: EmailController,
                                          decoration: InputDecoration(
                                            enabledBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    139, 183, 183, 183),
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            focusedBorder: OutlineInputBorder(
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    139, 183, 183, 183),
                                                width: 1.0,
                                              ),
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                            ),
                                            hintText: "Enter your email",
                                            label: Text("Email",
                                                style: GoogleFonts.aBeeZee(
                                                    color: Colors.black45)),
                                            prefixIcon: const Icon(
                                                Icons.email_outlined),
                                            prefixIconColor: Utill.textcolor,
                                            hintStyle: TextStyle(
                                              color: Colors.grey[400],
                                            ),
                                          ),
                                          validator: (value) {
                                            if (value!.isEmpty) {
                                              return 'Please enter your Email Address';
                                            }
                                            final emailRegex = RegExp(
                                                r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$');
                                            if (!emailRegex.hasMatch(value)) {
                                              return 'Invalid email format';
                                            } else {
                                              email = EmailController.text;
                                            }
                                            return null;
                                          }),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      TextFormField(
                                        obscureText: true,
                                        controller: PasswordController,
                                        decoration: InputDecoration(
                                          hintText: "Password",
                                          enabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                              color: Color.fromARGB(
                                                  139, 183, 183, 183),
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                              color: Color.fromARGB(
                                                  139, 183, 183, 183),
                                              width: 1.0,
                                            ),
                                            borderRadius:
                                                BorderRadius.circular(10),
                                          ),
                                          label: Text(
                                            "Password",
                                            style: GoogleFonts.aBeeZee(
                                                color: Colors.black45),
                                          ),
                                          prefixIcon:
                                              const Icon(Icons.lock_outline),
                                          prefixIconColor: Utill.textcolor,
                                          hintStyle: TextStyle(
                                            color: Colors.grey[400],
                                          ),
                                        ),
                                        validator: (value) {
                                          if (value!.isNotEmpty) {
                                            password = PasswordController.text;
                                          } else {
                                            return 'Please enter your password';
                                          }
                                          return null;
                                        },
                                      ),
                                      const SizedBox(
                                        height: 20,
                                      ),
                                      Consumer<Credentialsprovider>(
                                        builder: (context, value, child) {
                                          print("Visible");
                                          return TextFormField(
                                            controller:
                                                ConfirmPasswordController,
                                            obscureText: value.isobscure,
                                            decoration: InputDecoration(
                                              label: Text(
                                                "Confirm Password",
                                                style: GoogleFonts.aBeeZee(
                                                    color: Colors.black45),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                  color: Color.fromARGB(
                                                      139, 183, 183, 183),
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              focusedBorder: OutlineInputBorder(
                                                borderSide: const BorderSide(
                                                  color: Color.fromARGB(
                                                      139, 183, 183, 183),
                                                  width: 1.0,
                                                ),
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              hintText: "Confirm Password",
                                              suffixIcon: IconButton(
                                                icon: Icon(value.isobscure
                                                    ? Icons.visibility
                                                    : Icons.visibility_off),
                                                onPressed: () {
                                                  value.passwordVisible();
                                                },
                                              ),
                                              prefixIcon: const Icon(
                                                  Icons.lock_outline),
                                              prefixIconColor: Utill.textcolor,
                                              hintStyle: TextStyle(
                                                color: Colors.grey[400],
                                              ),
                                            ),
                                            validator: (value) {
                                              if (value!.isEmpty) {
                                                return "please enter a Confirm Password";
                                              } else if (value != password) {
                                                return "Passwords Do Not Matched";
                                              }
                                              return null;
                                            },
                                          );
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 25,
                ),
                FadeAnimation(
                  1.3,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        height: 45,
                        width: 200,
                        decoration: BoxDecoration(
                          color: Utill.offshadecolor,
                          shape: BoxShape.rectangle,
                          borderRadius: const BorderRadius.horizontal(
                            left: Radius.circular(120.0),
                          ),
                          boxShadow: [
                            BoxShadow(
                                color: Utill.textcolor,
                                blurRadius: 8,
                                offset: const Offset(5, 0)),
                          ],
                        ),
                        child: Consumer<Credentialsprovider>(
                          builder: (context, value, child) {
                            return ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                elevation: 0,
                                backgroundColor: Utill.textcolor,
                              ),
                              onPressed: () {
                                if (SignUpKey.currentState!.validate()) {
                                  value.changesignupstate(
                                      context,
                                      EmailController.text,
                                      ConfirmPasswordController.text,
                                      FnameController.text);

                                  SignUpKey.currentState!.reset();
                                }
                              },
                              child: value.isloading
                                  ? const CircularProgressIndicator(
                                      valueColor: AlwaysStoppedAnimation<Color>(
                                          Colors.white),
                                    )
                                  : const Text(
                                      "Sign Up",
                                      style: TextStyle(
                                        color: Colors.white,
                                        letterSpacing: 1.5,
                                      ),
                                    ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                FadeAnimation(
                  1.5,
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: TextButton.icon(
                          style: TextButton.styleFrom(
                              foregroundColor: Utill.textcolor,
                              textStyle: const TextStyle(fontSize: 20)),
                          icon: const Icon(Icons.arrow_back),
                          onPressed: () {
                            Navigator.pushNamed(context, RoutesName.loginpage);
                          },
                          label: Text(
                            "Log in",
                            style: GoogleFonts.poppins(
                              fontSize: 25,
                              fontWeight: FontWeight.bold,
                              color: const Color.fromRGBO(
                                97,
                                97,
                                97,
                                1.000,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
