import 'package:ellemora/Providers/ApiProductsProvider.dart';
import 'package:ellemora/Providers/CredentialsProvider.dart';
import 'package:ellemora/Providers/MyCartsprovider.dart';
import 'package:ellemora/utills/routes.dart';
import 'package:ellemora/utills/routesname.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'firebase_options.dart';

void main() async {
  runApp(const MainApp());
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => Credentialsprovider()),
        ChangeNotifierProvider(create: (context) => ApiProductsProvider()),
        ChangeNotifierProvider(create: (context) => MycartsProvider()),
      ],
      child: const MaterialApp(
        initialRoute: RoutesName.splash,
        onGenerateRoute: Routes.generateroutes,
      ),
    );
  }
}
