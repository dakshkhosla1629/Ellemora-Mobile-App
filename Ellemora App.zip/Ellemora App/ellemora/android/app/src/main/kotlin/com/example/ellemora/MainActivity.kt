package com.example.ellemora

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
